package in.bham.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.bham.dao.IOrderrepo;
import in.bham.dao.IUserManrepo;
import in.bham.exception.OrderNotFoundException;
import in.bham.model.Order;
import in.bham.model.UserMan;

@Service
public class OrderSericeImpl implements IOrderService {
	
	@Autowired
	private IUserManrepo urepo;
	
	@Autowired
	private IOrderrepo orepo;

	@Override
	public List<Order> getOrderByUser(Integer uid) {
		
		 List<Order> list = orepo.findByUid(uid);
		if(list.isEmpty()) {
			throw new OrderNotFoundException("There is no order found for the given User");
		}
		return list;
	}

}
