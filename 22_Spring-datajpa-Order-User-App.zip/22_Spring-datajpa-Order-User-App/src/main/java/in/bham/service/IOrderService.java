package in.bham.service;

import java.util.List;

import in.bham.model.Order;
import in.bham.model.UserMan;

public interface IOrderService {
	
	public List<Order> getOrderByUser(Integer uid);
	

}
