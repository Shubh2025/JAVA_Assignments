package in.bham.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="userman")
public class UserMan {
	
	@Id
	private Integer uid;
	private String userName;
	private String address;
	

}
