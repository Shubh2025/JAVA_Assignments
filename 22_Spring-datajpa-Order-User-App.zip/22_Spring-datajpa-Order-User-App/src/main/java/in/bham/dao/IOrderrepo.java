package in.bham.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import in.bham.model.Order;
import in.bham.model.UserMan;

public interface IOrderrepo extends JpaRepository<Order, Integer> {

	@Query("FROM in.bham.model.Order where uid=:uid")
	public List<Order> findByUid(Integer uid);
}
