package in.bham.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import in.bham.model.UserMan;

public interface IUserManrepo extends JpaRepository<UserMan, Integer> {

}
