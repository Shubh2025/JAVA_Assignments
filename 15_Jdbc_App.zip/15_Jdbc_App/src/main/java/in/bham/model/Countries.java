package in.bham.model;

import lombok.Data;

@Data
public class Countries {
	
	private Integer cid;
	private String name;
	private String capital;
	private String official_language;

}
