package in.bham.dao;

import java.util.List;

import in.bham.model.Countries;

public interface ICountriesRepo {
	
	public Countries getCountry(Integer id);
	
	public List<Countries> getAll();

}
