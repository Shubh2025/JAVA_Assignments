package in.bham.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import in.bham.model.Countries;
import in.bham.util.Jdbcutil;

public class CountriesdaoImpl implements ICountriesRepo {
	
	Connection connection=null;
	PreparedStatement pst=null;
	ResultSet rst=null;
	
	@Override
	public Countries getCountry(Integer id) {
		
		Countries country=null;
		
		 try {
			connection = Jdbcutil.getJdbcConnection();
			
			 pst = connection.prepareStatement("select capital,name,official_language from countries where cid=?");
			 
			 if(pst!=null) {
				 pst.setInt(1, id);
				 
				  rst = pst.executeQuery();
			 }
			 
			 if(rst!=null) {
			 while(rst.next()) {
				 
				 Countries countries = new Countries();
				 
				 countries.setCapital(rst.getString(1));
				 countries.setName(rst.getString(2));
				 countries.setOfficial_language(rst.getString(3));
				 
				 
				 return countries;
			 }
			 	 
			 } 
			 
		} catch (SQLException | IOException e) {
			e.printStackTrace();
		}
		 return country;
		
	}

	@Override
	public List<Countries> getAll() {
		
		List<Countries> list=new ArrayList();
		
		 try {
			 
			connection = Jdbcutil.getJdbcConnection();
			if(connection!=null) {
				
				pst = connection.prepareStatement("select capital,name,official_language from countries");
			}
			if(pst!=null) {
				
				rst=pst.executeQuery();
			}
			
			if(rst!=null) {
				
				while(rst.next()) {
					
					Countries c=new Countries();
					
					c.setCapital(rst.getString(1));
					c.setName(rst.getString(2));
					c.setOfficial_language(rst.getString(3));
					
					list.add(c);
				}
				
				return list;
				
			}
			
			
		} catch (SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
		
	}

}
