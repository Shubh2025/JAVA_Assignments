package in.bham.servicefactory;

import in.bham.service.CountryServiceImpl;
import in.bham.service.ICountryService;

public class ServiceFactory {
	
	private ServiceFactory() {};
	
	private static ICountryService countryService=null;
	
	public static ICountryService getService() {
		
		if(countryService==null) {
			countryService=new CountryServiceImpl();
		}
		
		return countryService;
	}

}
