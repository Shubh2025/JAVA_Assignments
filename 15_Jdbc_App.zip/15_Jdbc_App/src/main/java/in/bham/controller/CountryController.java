package in.bham.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.bham.model.Countries;
import in.bham.service.ICountryService;
import in.bham.servicefactory.ServiceFactory;

/**
 * Servlet implementation class CountryController
 */
@WebServlet("/CountryController/*")
public class CountryController extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public CountryController() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 
		doProcess(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doProcess(request, response);
	}
	
	private void doProcess(HttpServletRequest request, HttpServletResponse response) throws IOException {
		
		ICountryService countryService=ServiceFactory.getService();
		
		PrintWriter out = response.getWriter();
		if(request.getRequestURI().endsWith("searchFormById")) {
			
			String id = request.getParameter("id");
			Countries coun = countryService.getCountryById(Integer.parseInt(id));
			if(coun!=null) {
				
				out.println("<h1>");
				out.println("<body>");
				out.println("<center>");
				out.println("<br/><br/><br/><br/>");
				out.println("<h3>Required Record is Following::</h3>");
				
				out.println("<table  border='1'>");
				
				out.println("<tr  >");
				out.println("<th>ID</th><td>"+coun.getName()+"</td>");
				out.println("</tr>");
				
				out.println("<tr  >");
				out.println("<th>Age</th><td>"+coun.getCapital()+"</td>");
				out.println("</tr>");
				
				out.println("<tr  >");
				out.println("<th>Address</th><td>"+coun.getOfficial_language()+"</td>");
				out.println("</tr>");
				
				out.println("</table>");
				out.println("</center>");
				out.println("</body>");
				out.println("</h1>");
			}
			
			
		}
		
		if(request.getRequestURI().endsWith("searchForm")) {
			
			List<Countries> list = countryService.getAllCountries();
			
		if(list.isEmpty()) {
			
			out.println("<h1>");
			out.println("<body>");
			out.println("<center>");
			out.println("<br/><br/><br/><br/>");
			out.println("<h3>THERE IS NO DATA AVAILABLE IN DATABASE::</h3>");
			
			out.println("</center>");
			out.println("</body>");
			out.println("</h1>");
			
		}
			
		else {
			
			out.println("<h1>");
			out.println("<body>");
			out.println("<center>");
			out.println("<br/><br/><br/><br/>");
			out.println("<h3>Required Record is Following::</h3>");
			
			out.println("<table  border='1'>");
			
			out.println("<th>NAME</th>");
			out.println("<th>CAPITAL</th>");
			out.println("<th>LANGUAGE</th>");
			for(Countries coun:list) {
				
				
				out.println("<tr  >");
				out.println("<td>"+coun.getName()+"</td>");
				//out.println("</tr>");
				
				//out.println("<tr  >");
				out.println("<td>"+coun.getCapital()+"</td>");
				//out.println("</tr>");
				
				//out.println("<tr  >");
				out.println("<td>"+coun.getOfficial_language()+"</td>");
				out.println("</tr>");
			}
			
			
			out.println("</table>");
			out.println("</center>");
			out.println("</body>");
			out.println("</h1>");
		}
			
			
		}
		
	}

}
