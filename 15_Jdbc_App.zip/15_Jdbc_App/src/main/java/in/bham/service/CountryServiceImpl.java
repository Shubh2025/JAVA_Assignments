package in.bham.service;

import java.util.List;

import in.bham.dao.ICountriesRepo;
import in.bham.daofactory.CountryFactory;
import in.bham.model.Countries;

public class CountryServiceImpl implements ICountryService {
	
	private ICountriesRepo repo;

	@Override
	public Countries getCountryById(Integer id) {
		
		 repo = CountryFactory.getrepo();
		 
		 Countries country = repo.getCountry(id);
		
		return country;
	}

	@Override
	public List<Countries> getAllCountries() {
		
		repo=CountryFactory.getrepo();
		List<Countries> list = repo.getAll();
		
		return list;
	}

}
