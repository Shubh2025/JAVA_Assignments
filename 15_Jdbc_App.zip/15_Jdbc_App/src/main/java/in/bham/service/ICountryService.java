package in.bham.service;

import java.util.List;

import in.bham.model.Countries;

public interface ICountryService {
	
	public Countries getCountryById(Integer id);
	
	public List<Countries> getAllCountries();

}
