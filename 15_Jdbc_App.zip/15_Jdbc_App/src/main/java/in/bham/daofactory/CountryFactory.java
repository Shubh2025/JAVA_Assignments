package in.bham.daofactory;

import in.bham.dao.CountriesdaoImpl;
import in.bham.dao.ICountriesRepo;

public class CountryFactory {
	
	private  CountryFactory() {};
	
	private static ICountriesRepo countriesRepo=null;
	
	public static ICountriesRepo getrepo() {
		
		if(countriesRepo==null) {
			countriesRepo=new CountriesdaoImpl();
		}
		
		return countriesRepo;
	}

}
