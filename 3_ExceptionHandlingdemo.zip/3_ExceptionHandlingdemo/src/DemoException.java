import java.util.Scanner;

public class DemoException {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("ENTER INTEGER NUMBER");
		int num = sc.nextInt();
		
		try {
			if(num<0)
				throw new Exception();
			else {
				System.out.println("Well done");
			}
		}catch (Exception e) {
			
			System.out.println("WRONG INPUT::Please Enter Positive Numbers Only");
		}
	}

}
