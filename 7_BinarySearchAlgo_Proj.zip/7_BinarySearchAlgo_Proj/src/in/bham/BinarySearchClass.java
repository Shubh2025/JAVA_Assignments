package in.bham;

import java.util.Scanner;

public class BinarySearchClass {
	
	public int binarySea(int[] arr,int x) {
		
		int s=0;
		int e=arr.length-1;
		
		while(s<=e) {
			
			int m=s+(e-s)/2;
			
			if(arr[m]==x) {
				return m;
			}
			if(arr[m]<x) {
				s=m+1;
			}
			else {
				e=m-1;
			}
			
		}
		
		return -1;		
	}
	
	
	
	public static void main(String[] args) {
		
		BinarySearchClass bs=new BinarySearchClass();
		
		int[] arr= {-56,0,12,98,103,208,450,540};
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number you want to search into Array");
		int num = sc.nextInt();
		
		int result = bs.binarySea(arr, num);
		
		if(result<0) {
			System.out.println("Sorry number is not available into array");
		}
		else {
			System.out.println("index of the number is "+result);
		}
		
		
	}

}
