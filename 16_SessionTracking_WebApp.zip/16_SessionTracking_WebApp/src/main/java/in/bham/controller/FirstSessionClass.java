package in.bham.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class FirstSessionClass
 */
@WebServlet("/first")
public class FirstSessionClass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String name = request.getParameter("name");
		String age = request.getParameter("age");
		
		HttpSession session = request.getSession();
		session.setAttribute("name", name);
		session.setAttribute("age", age);
		
	    PrintWriter out = response.getWriter();
	    
	    
		out.println("<html><head><title> form</title></head>");
		out.println("<body bgcolor='cyan'>");
		out.println("<center>");
		out.println("<h1 style='color:red;'>Comany form...</h1>");
		out.println("<form method='post' action='" + response.encodeURL("./second") + "'>");
		out.println("<table>");
		out.println("<tr><th>Name</th><td>"+name+"</td></tr>");
		out.println("<tr><th>Company</th><td><input type='text' name='comp'/></td></tr>");
		out.println("<tr><th>roll</th><td><input type='text' name='roll'/></td></tr>");
		out.println("<tr><th></th><td><input type='submit' value='next'/></td></tr>");
		out.println("</table>");
		out.println("</form>");
		out.println("</center>");
		out.println("</body>");
		out.println("</html>");

	}

}
