package in.bham.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class SecondSessionClass
 */
@WebServlet("/second")
public class SecondSessionClass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String company = request.getParameter("comp");
		String roll = request.getParameter("roll");
		
		HttpSession session = request.getSession(false);
		session.setAttribute("company", company);
		session.setAttribute("roll", roll);
		
		PrintWriter out = response.getWriter();
		
		
		out.println("<html><head><title>Deposit form</title></head>");
		out.println("<body bgcolor='cyan'>");
		out.println("<center>");
		out.println("<h1 style='color:red;'>Final Result...</h1>");
		out.println("<form method='post' action='" + response.encodeURL("./second") + "'>");
		out.println("<table>");
		out.println("<tr><th>Name</th><td>"+session.getAttribute("name")+"</td></tr>");
		out.println("<tr><th>Age</th><td>"+session.getAttribute("age")+"</td></tr>");
		out.println("<tr><th>Company</th><td>"+company+"</td></tr>");
		out.println("<tr><th>roll of employee</th><td>"+roll+"</td></tr>");
		out.println("</table>");
		out.println("</form>");
		out.println("</center>");
		out.println("</body>");
		out.println("</html>");
		
		
	}

}
