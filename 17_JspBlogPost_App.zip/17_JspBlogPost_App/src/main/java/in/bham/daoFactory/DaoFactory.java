package in.bham.daoFactory;

import in.bham.dao.BlogRepoImpl;
import in.bham.dao.IBlogRepo;

public class DaoFactory {
	
	private DaoFactory() {};
	
	private static IBlogRepo blogRepo=null;
	
	public static IBlogRepo getDao() {
		
		if(blogRepo==null) {
			blogRepo=new BlogRepoImpl();
		}
		
		return blogRepo;
	}

}
