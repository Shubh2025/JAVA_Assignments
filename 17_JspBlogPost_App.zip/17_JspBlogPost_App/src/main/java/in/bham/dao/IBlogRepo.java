package in.bham.dao;

import java.util.List;

import in.bham.entiry.Blog;

public interface IBlogRepo {
	
	public String postBlog(Blog blog);
	
	public Blog getBlogById(Integer bid);
	
	public List<Blog> getAllBlogs();

}
