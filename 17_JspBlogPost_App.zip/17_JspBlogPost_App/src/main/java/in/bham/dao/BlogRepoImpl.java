package in.bham.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import in.bham.entiry.Blog;
import in.bham.util.JdbcUtil;

public class BlogRepoImpl implements IBlogRepo {
	
	private static final String POST_BLOG = "insert into blogs(title,descript,content)values(?,?,?)";
	Connection connection=null;
	PreparedStatement pst=null;
	ResultSet rst=null;

	@Override
	public String postBlog(Blog blog) {
		
		int rowAffected=0;
		
		 try {
			connection = JdbcUtil.getJdbcConnection();
			
			if(connection!=null) {
				pst=connection.prepareStatement(POST_BLOG);
			}
			if(pst!=null) {
				
				pst.setString(1, blog.getTitle());
				pst.setString(2, blog.getDescription());
				pst.setString(3, blog.getContent());
				
				rowAffected=pst.executeUpdate();
			}
			
			if(rowAffected>0) {
				return "success";
			}
			
			
		} catch (IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return "Fail";
	}

	@Override
	public Blog getBlogById(Integer bid) {
		
		try {
			connection=JdbcUtil.getJdbcConnection();
			
			if(connection!=null) {
				
				String GET_POST_BYID="select title,descript,content from blogs where bid=?";
				pst=connection.prepareStatement(GET_POST_BYID);
				
			}
			if(pst!=null) {
				
			    pst.setInt(1, bid);
			    
				rst=pst.executeQuery();			
			}
			if(rst!=null) {
				
				
				while(rst.next()) {
					
					Blog b=new Blog();
					
					b.setTitle(rst.getString(1));
					b.setDescription(rst.getString(2));
					b.setContent(rst.getString(3));
					
					return b;
				}
				
			}
			
		} catch (IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

	@Override
	public List<Blog> getAllBlogs() {
		
	    List<Blog> list = new ArrayList<>(); 
		
		try {
			connection=JdbcUtil.getJdbcConnection();
			
			if(connection!=null) {
				
				String GET_POST_BYID="select title,descript,content from blogs ";
				pst=connection.prepareStatement(GET_POST_BYID);
				
			}
			if(pst!=null) {
				rst=pst.executeQuery();			
			}
			if(rst!=null) {
				
			
				while(rst.next()) {
					Blog b=new Blog();
					
					b.setTitle(rst.getString(1));
					b.setDescription(rst.getString(2));
					b.setContent(rst.getString(3));
					
					list.add(b);
					
				}
				
				return list;
					
				}
			}catch(IOException | SQLException e) {
				e.printStackTrace();
			}
		
		return list;
	}

}
