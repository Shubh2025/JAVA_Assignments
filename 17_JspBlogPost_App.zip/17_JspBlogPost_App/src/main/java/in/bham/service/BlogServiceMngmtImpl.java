package in.bham.service;

import java.util.List;

import in.bham.dao.IBlogRepo;
import in.bham.daoFactory.DaoFactory;
import in.bham.entiry.Blog;

public class BlogServiceMngmtImpl implements IBlogServiceMngmt {
	
	private IBlogRepo repo;	

	@Override
	public String addBlog(Blog blog) {
		
		repo=DaoFactory.getDao();
		
		String status = repo.postBlog(blog);
		
		return status;
	}

	@Override
	public Blog fetchBlogById(Integer bid) {
		
		repo=DaoFactory.getDao();
		
		Blog blog = repo.getBlogById(bid);
		
		return blog;
	}

	@Override
	public List<Blog> getAllBlogs() {
		
		repo=DaoFactory.getDao();
		
		List<Blog> list = repo.getAllBlogs();
		
		return list;
	}

}
