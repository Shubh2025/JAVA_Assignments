package in.bham.service;

import java.util.List;

import in.bham.entiry.Blog;

public interface IBlogServiceMngmt {
	
	public String addBlog(Blog blog);
	
	public Blog fetchBlogById(Integer bid);
	
	public List<Blog> getAllBlogs();

}
