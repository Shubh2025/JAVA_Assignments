package in.bham.serviceFactory;

import in.bham.service.BlogServiceMngmtImpl;
import in.bham.service.IBlogServiceMngmt;

public class ServiceFactory {
	
	private ServiceFactory() {};
	
	private static IBlogServiceMngmt blogServiceMngmt=null;
	
	public static IBlogServiceMngmt getService() {
		
		if(blogServiceMngmt==null) {
			blogServiceMngmt=new BlogServiceMngmtImpl();
		}
		return blogServiceMngmt;
	}
	

}
