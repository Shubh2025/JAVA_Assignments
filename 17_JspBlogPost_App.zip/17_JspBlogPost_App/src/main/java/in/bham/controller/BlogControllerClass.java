package in.bham.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.bham.entiry.Blog;
import in.bham.service.IBlogServiceMngmt;
import in.bham.serviceFactory.ServiceFactory;


@WebServlet("/blog/*")
public class BlogControllerClass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doProcess(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doProcess(request, response);
	}
	
	public void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		//inject the srviceimpl object
	  IBlogServiceMngmt service=ServiceFactory.getService();	
	  
		if(request.getRequestURI().endsWith("addblog")) {
			
			String title = request.getParameter("title");
			String desc = request.getParameter("descrip");
			String content = request.getParameter("content");
			
			//create the blog object and set the values which we got from the view part
			Blog b=new Blog();
			
			b.setTitle(title);
			b.setDescription(desc);
			b.setContent(content);
			
			String status = service.addBlog(b);
			
			if(status.equalsIgnoreCase("success")) {
				
				request.setAttribute("status", "success");
				RequestDispatcher rsd = request.getRequestDispatcher("../success.jsp");
				rsd.forward(request, response);
			}else {
				request.setAttribute("status", "failure");
				RequestDispatcher rsd = request.getRequestDispatcher("../success.jsp");
				rsd.forward(request, response);
			}
			
			
		}
		
		if(request.getRequestURI().endsWith("getpostById")) {
			
			String bid = request.getParameter("bid");
			
			Blog blog = service.fetchBlogById(Integer.parseInt(bid));
			
			request.setAttribute("blog", blog);
			RequestDispatcher rsd = request.getRequestDispatcher("../getPage.jsp");
			rsd.forward(request, response);
					
			
		}
		
		if(request.getRequestURI().endsWith("allData")) {
			
			List<Blog> list = service.getAllBlogs();
			
			request.setAttribute("list", list);
			RequestDispatcher rsd = request.getRequestDispatcher("../display.jsp");
		    rsd.forward(request, response);
			
		}
	}

}
