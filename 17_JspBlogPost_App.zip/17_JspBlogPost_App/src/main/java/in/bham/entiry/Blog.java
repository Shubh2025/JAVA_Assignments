package in.bham.entiry;

import lombok.Data;

@Data
public class Blog {
	
	private Integer blogId;
	private String title;
	private String description;
	private String content;
	

}
