import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Test {

	public static void main(String[] args) {

		Scanner sc =new Scanner(System.in);
		
		ArrayList<Integer> list = new ArrayList<Integer>();
		
		HashSet<Integer> set = new HashSet<Integer>();
		
		while(true) {
			
			System.out.println("...Enter the number...");	
			int i = sc.nextInt();
			
			set.add(i);
			
			System.out.println("Do you want to add more number(Y/N)");
			String ans = sc.next();
			
			if(ans.equalsIgnoreCase("N")) {
				break;
			}
		}
		
		System.out.println(set);
		System.out.println("####");
		System.out.println("");
		
		list.addAll(set);
		
		System.out.println(list);
		System.out.println();
		
		List<Integer> collect = list.stream().sorted().collect(Collectors.toList());
		System.out.println(collect);
		
		System.out.println("second smallest number is "+collect.get(1));
		System.out.println("second largest number is "+collect.get(collect.size()-2));
		
		
	}

}
