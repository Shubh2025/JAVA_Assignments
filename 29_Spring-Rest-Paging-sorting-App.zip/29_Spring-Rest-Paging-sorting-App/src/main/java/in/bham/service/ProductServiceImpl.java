package in.bham.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import in.bham.dao.IProductsRepo;
import in.bham.exception.ProductNotFoundException;
import in.bham.model.Products;

@Service
@Transactional
public class ProductServiceImpl implements IProductsService {

	@Autowired
	private IProductsRepo repo;
//	
//	

	@Override
	public Products getProductById(Integer productId) {
		
		Optional<Products> optional = repo.findById(productId);
		Products products = optional.orElseThrow(()-> new ProductNotFoundException("Product for the given Id Not available"));
		
		return products;
				
	}

	@Override
	public Iterable<Products> getAll(String property) {
		
		PageRequest request = PageRequest.of(0, 2, Sort.by(property));
		
				
	     Page<Products> page = repo.findAll(request);
		
		if(page.isEmpty()) {
			throw new ProductNotFoundException("There Is No Product Available.");
		}
		return page.getContent();
	}

	@Override
	public Iterable<Products> getAllOrderBydate(Date date) {
		
		Iterable<Products> iterable = repo.findAll(Sort.by(date.toString()));
		return iterable;
	}

	@Override
	public List<Products> getProductsByDate(Date date1, Date date2) {
		
		List<Products> list = repo.serachProductsByDate(date1, date2);
		
		return list;
	}
	
	

}
