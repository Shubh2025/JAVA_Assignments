package in.bham.service;

import java.util.Date;
import java.util.List;

import in.bham.model.Products;

public interface IProductsService {

	//public String addProduct(Products products);
	
	public Products getProductById(Integer productId);
	
	public Iterable<Products> getAll(String property);
	
	public Iterable<Products> getAllOrderBydate(Date date);
	
	public List<Products> getProductsByDate(Date date1,Date date2);
}
