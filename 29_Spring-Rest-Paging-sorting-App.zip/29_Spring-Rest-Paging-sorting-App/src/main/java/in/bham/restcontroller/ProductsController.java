package in.bham.restcontroller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import in.bham.model.Products;
import in.bham.service.IProductsService;

@RestController
@RequestMapping("/api/product")
public class ProductsController {
	
	@Autowired
	private IProductsService service;

	
	@GetMapping("/get/{pid}")
	public ResponseEntity<Products> fetchProductById(@PathVariable Integer pid){
		
		Products prod = service.getProductById(pid);
		
		return new ResponseEntity<Products>(prod, HttpStatus.OK);
		
	}
	
	@GetMapping("/getAll/{prop}")
	public ResponseEntity<List<Products>> fetchAllProducts(@PathVariable String prop){
		
		List<Products> list = (List<Products>) service.getAll(prop);
		
		return new ResponseEntity<List<Products>>(list,HttpStatus.FOUND);
	}
	
	@GetMapping("/getAll/date/{date}")
	public ResponseEntity<List<Products>> fetchAllProductsByDate(@PathVariable @DateTimeFormat(pattern =  "yyyy-MM-dd") String date){
		
		List<Products> list = (List<Products>) service.getAll(date);
		
		return new ResponseEntity<List<Products>>(list,HttpStatus.FOUND);
	}
	
	@GetMapping("/getAll/bydate")
	public ResponseEntity<List<Products>> fetchProductsByDate(@RequestParam  String date1,@RequestParam  String date2) throws Exception{
		
		   Date d1=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(date1);  
		   Date d2=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(date2);  
		
		List<Products> list = service.getProductsByDate(d1, d2);
		
		return new ResponseEntity<List<Products>>(list,HttpStatus.OK);
	}

}
