package in.bham.dao;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import in.bham.model.Products;

public interface IProductsRepo extends PagingAndSortingRepository<Products, Integer> {

	
	@Query("FROM in.bham.model.Products WHERE mfg_date IN(:date1,:date2)")
	public List<Products> serachProductsByDate(Date date1,Date date2);
}
