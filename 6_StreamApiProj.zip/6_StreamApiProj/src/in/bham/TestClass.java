package in.bham;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class TestClass {

	public static void main(String[] args) {

		ArrayList<Integer> list = new ArrayList<>();
		
		list.add(12);
		list.add(72);
		list.add(19);
		list.add(-2);
		list.add(120);
		
		List<Integer> list2 = list.stream().map(a -> a*2).
				filter(num -> (num>30)).
				collect(Collectors.toList());
		
		System.out.println(list2);
		
		List<Integer> list3 = list.stream().map(a -> a*3).
				sorted(Comparator.reverseOrder())
				.collect(Collectors.toList());
		
		System.out.println(list3);
	}

}
