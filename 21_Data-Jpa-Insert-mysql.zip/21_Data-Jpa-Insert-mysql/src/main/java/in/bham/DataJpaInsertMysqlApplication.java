package in.bham;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

import in.bham.model.Country;
import in.bham.service.ICountryInfoService;

@SpringBootApplication
public class DataJpaInsertMysqlApplication {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(DataJpaInsertMysqlApplication.class, args);
		
		ICountryInfoService service = context.getBean(ICountryInfoService.class);
		String response = service.addCountry(new Country("Russia", "Moskow", "russian"));
		System.out.println(response);
		
		((ConfigurableApplicationContext) context).close();
		
	}

}
