package in.bham.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import in.bham.model.Country;

public interface ICountryInfoRepo extends JpaRepository<Country, Integer> {

}
