package in.bham.service;

import in.bham.model.Country;

public interface ICountryInfoService {
	
	public String addCountry(Country country);

}
