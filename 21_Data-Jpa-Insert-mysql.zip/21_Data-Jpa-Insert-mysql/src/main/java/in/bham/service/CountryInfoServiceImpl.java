package in.bham.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.bham.dao.ICountryInfoRepo;
import in.bham.model.Country;

@Service
public class CountryInfoServiceImpl implements ICountryInfoService {
	
	@Autowired
	private ICountryInfoRepo repo;

	@Override
	public String addCountry(Country country) {

		Country cou = repo.save(country);
		if(cou==null) {
			return "Registration got failed";
		}
		else
		return "Country has been added with Id: "+cou.getCid();
	}

}
