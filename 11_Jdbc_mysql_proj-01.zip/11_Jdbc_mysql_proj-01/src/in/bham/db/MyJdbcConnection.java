package in.bham.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MyJdbcConnection {


	public static void main(String[] args) {
		
		
		Connection connection=null;
		Statement statement=null;
		ResultSet rSet=null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Driver class has been registered");
			
			String url="jdbc:mysql:///assignment_spring";
			String username="root";
			String password="bhamp@143";
			
			 connection = DriverManager.getConnection(url, username, password);
			 System.out.println("connection has been established");
			 
			 statement=connection.createStatement();
			 System.out.println("statement object has benn created");
			 
			  rSet = statement.executeQuery("select capital,name,official_language from countries");
			  
			  System.out.println();
			  
			  System.out.println("NAME\tCAPITAL\tLANGUAGE");
			  
			  while(rSet.next()) {
				  
				  System.out.println();
				  String capital = rSet.getString(1);
				  String name = rSet.getString(2);
				  String language = rSet.getString(3);
				  
				  System.out.println(name+"\t"+capital+"\t"+language);
				  
			  }
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		finally {
			
			if(rSet!=null) {
				try {
					rSet.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			
			if(statement!=null) {
				try {
					statement.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			if(connection!=null) {
				try {
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		}

	}

}
