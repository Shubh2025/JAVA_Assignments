package in.bham;



interface Shapes{
	
	 void area() ;
}



class lambchoras implements Shapes{
	
	int length=200;
	int breadth=120;

	public void area() {
		
		System.out.println("Area of the Rectangle");
		System.out.println(length*breadth); 
		
	}
	
}

class Square implements Shapes{
	
	int l=10;

	public void area() {
		System.out.println("Area of the Square");
		System.out.println(l*l);
	}
	
	
}

class Circle implements Shapes{

	int radius=5;
	
	public void area() {
		System.out.println("Area of the circle");
		System.out.println(3.14*radius*radius); 
	}
	
}



public class TestClass {

	public static void main(String[] args) {

	   Shapes s;
	   
	   s=new lambchoras();
	   s.area();
	   
	   s=new Square();
	   s.area();
	   
	   s=new Circle();
	   s.area();
		
	}

}
