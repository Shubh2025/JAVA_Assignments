package in.bham.restcontroller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import in.bham.model.Products;
import in.bham.service.IProductsService;

@RestController
@RequestMapping("/api/product")
public class ProductsController {
	
	@Autowired
	private IProductsService service;

	@PostMapping("/add")
	public ResponseEntity<String> addProduct(@RequestBody Products products){
		
		String succesMsg = service.addProduct(products);
		
		return new ResponseEntity<String>(succesMsg,HttpStatus.CREATED);
		
	}
	
	@GetMapping("/get/{pid}")
	public ResponseEntity<Products> fetchProductById(@PathVariable Integer pid){
		
		Products prod = service.getProductById(pid);
		
		return new ResponseEntity<Products>(prod, HttpStatus.OK);
		
	}
	
	@GetMapping("/getAll")
	public ResponseEntity<List<Products>> fetchAllProducts(){
		
		List<Products> list = service.getAll();
		
		return new ResponseEntity<List<Products>>(list,HttpStatus.FOUND);
	}
	
	@PutMapping("/modify")
	public ResponseEntity<String> updateDetails(@RequestBody Products products){
		
		String resu = service.updateProduct(products);
		
		return new ResponseEntity<String>(resu,HttpStatus.OK);
	}
	
	@DeleteMapping("/delete/{pid}")
	public ResponseEntity<String> deleteById(@PathVariable Integer pid){
		
		String status = service.deletProductById(pid);
		
		return new ResponseEntity<String>(status, HttpStatus.OK);
	}
	
	@PatchMapping("/modify/{pid}")
	public ResponseEntity<String> updateMfgDateById(@PathVariable Integer pid, @RequestParam("mfg_date") @DateTimeFormat(pattern = "yyyy-MM-dd") Date mfg_date){
		
		String status = service.updateProductById(pid, mfg_date);
		
		return new ResponseEntity<String>(status, HttpStatus.OK);
	}
}
