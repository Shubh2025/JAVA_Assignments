package in.bham.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import in.bham.model.Products;

public interface IProductsRepo extends JpaRepository<Products,Integer> {

}
