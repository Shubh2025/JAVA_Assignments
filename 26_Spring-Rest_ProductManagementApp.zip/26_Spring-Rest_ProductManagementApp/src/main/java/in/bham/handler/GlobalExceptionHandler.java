package in.bham.handler;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import in.bham.error.ErrorInfo;
import in.bham.exception.ProductNotFoundException;

@RestControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler(ProductNotFoundException.class)
	public ResponseEntity<ErrorInfo> handleProductException(ProductNotFoundException p){
		
		ErrorInfo errorInfo = new ErrorInfo();
		errorInfo.setMsg(p.getMessage());
		errorInfo.setErrorcode("400 Series Error ");
		errorInfo.setTime(LocalDateTime.now());
		
		return new ResponseEntity<ErrorInfo>(errorInfo, HttpStatus.NOT_FOUND);
		
	}
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorInfo> geberalException(Exception e){
		
		ErrorInfo info = new ErrorInfo(e.getMessage(), "Internal Server 500 series error", LocalDateTime.now());
		
		return new ResponseEntity<ErrorInfo>(info, HttpStatus.INTERNAL_SERVER_ERROR);
		
	}

}
