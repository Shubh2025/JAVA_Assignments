package in.bham.service;

import java.util.Date;
import java.util.List;

import in.bham.model.Products;

public interface IProductsService {

	public String addProduct(Products products);
	
	public Products getProductById(Integer productId);
	
	public List<Products> getAll();
	
	public String updateProduct(Products products);
	
	public String deletProductById(Integer pid);
	
	public String updateProductById(Integer pid,Date mfgDate);
}
