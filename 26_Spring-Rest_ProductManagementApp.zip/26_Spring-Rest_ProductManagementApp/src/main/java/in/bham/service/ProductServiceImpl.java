package in.bham.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.bham.dao.IProductsRepo;
import in.bham.exception.ProductNotFoundException;
import in.bham.model.Products;

@Service
@Transactional
public class ProductServiceImpl implements IProductsService {

	@Autowired
	private IProductsRepo repo;
	
	@Override
	public String addProduct(Products products) {
		Products products2 = repo.save(products);
		
		return "Product with id: "+products2.getPid()+" has been added.";
	}

	@Override
	public Products getProductById(Integer productId) {
		
		Optional<Products> optional = repo.findById(productId);
		Products prod = optional.orElseThrow(()-> new ProductNotFoundException("For the Given Id Product Is Not Available"));
		return prod;
	}

	@Override
	public List<Products> getAll() {
		
		List<Products> list = repo.findAll();
		
		if(list.isEmpty()) {
			throw new ProductNotFoundException("There Is No Product Available.");
		}
		return list;
	}

	@Override
	public String updateProduct(Products products) {
		
		Optional<Products> optional = repo.findById(products.getPid());
		
		optional.orElseThrow(()-> new ProductNotFoundException("Product is not available"));
		
		repo.save(products);
		
		
		
		
		return "...Product updated Succesfully..";
	}

	

	@SuppressWarnings("deprecation")
	@Override
	public String updateProductById(Integer pid, Date mfgDate) {
		
		Optional<Products> optional = repo.findById(pid);
		
		int i=mfgDate.getDate()+1;
		mfgDate.setDate(i);
		
		Products products = optional.orElseThrow(()-> new ProductNotFoundException("Product not available"));
		
		products.setMfg_date(mfgDate);
		
		repo.save(products);
		
		return "Products mfg_date with id "+pid+" has been updated succesfully";
		

	}

	@Override
	public String deletProductById(Integer pid) {

		Optional<Products> optional = repo.findById(pid);
		optional.orElseThrow(()-> new ProductNotFoundException("Product Not Found.."));
		
		repo.deleteById(pid);
		
		return "Product with id: "+pid+" removed from table...";
	}
	
	

}
