package in.bham;

/* 
 * through interface we can achieve 100% abstraction 
 * in interfaces all methods are public and abstract wheather you declare or not
 * interface all variables are public static and final, hence it should be initialized at a time of declaration
 * interface doesn't contain constructor.
*/
interface School{
	
//	public School() {};-----> giving an compile time error
//  int x; ------>	giving an compile time error
	
	int fees=20000;
	public static String name="K.V";
	public static final String address="Gujarat"; 
	
	void getAdmission();
	double getScholarship();
	
}
/*
 * abstract class must be declared with the keyword "abstract"
 * abstract class can contain all methods (abstract,concrete)
 * abstract class does contain constructor
 * abstractb class does contain all type of methods such as public,abstract,protected etc..
 * it can also have all type of variables
 * 
 */

abstract class Student{
	
	int x;
	String name;
	
	public Student() {
		System.out.println("abstract class constrctor is created..");
	}
	 
	void getLoan() {
		System.out.println("got loan");
	}
	
	abstract void writeExam();
	
}

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
