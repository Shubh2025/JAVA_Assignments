package in.bham.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import in.bham.model.Country;

public interface IEurekaClientrepo extends JpaRepository<Country, Integer> {

}
