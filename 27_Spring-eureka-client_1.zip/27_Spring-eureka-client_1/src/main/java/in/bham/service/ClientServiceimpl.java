package in.bham.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.bham.dao.IEurekaClientrepo;
import in.bham.exception.CountryNotFoundException;
import in.bham.model.Country;

@Service
public class ClientServiceimpl implements IClientService {
	
	@Autowired
	private IEurekaClientrepo repo;

	@Override
	public Country getCountryById(Integer cid) {
		
		Optional<Country> optional = repo.findById(cid);
		Country country = optional.orElseThrow(()-> new CountryNotFoundException("No Country is there with given Id"));
			
		return country;
	}

	@Override
	public List<Country> getAll() {
		
		List<Country> list = repo.findAll();
		
		if(list.isEmpty()) {
			 throw new CountryNotFoundException("No country is available in database");
		}
		return list;
	}

}
