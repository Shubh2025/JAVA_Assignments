package in.bham.service;

import java.util.List;

import in.bham.model.Country;

public interface IClientService {
	
	public Country getCountryById(Integer cid);
	
	public List<Country> getAll();
	
}
