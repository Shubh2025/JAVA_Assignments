package in.bham.handler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import in.bham.exception.CountryNotFoundException;

@RestControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(CountryNotFoundException.class)
	public ResponseEntity<String> handleException(CountryNotFoundException c){
		
		return new ResponseEntity<String>(c.getMessage(), HttpStatus.NOT_FOUND);
	}
}
