package in.bham.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;

import lombok.Data;

@Data
@Entity
@DynamicInsert(value=true)
@Table(name="countries")
public class Country {
	
	@Id
	private Integer cid;
	private String capital;
	private String name;
	private String official_language;

}
