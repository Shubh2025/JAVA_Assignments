package in.bham.test;

import java.util.Scanner;

import org.hibernate.Session;

import in.bham.entity.Country;
import in.bham.util.HibernateUtil;

public class FetchDataClass {

	public static void main(String[] args) {
		
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		System.out.println("enter id of the country");
		int sid=sc.nextInt();
			
		Session session=null;
	
		 session=HibernateUtil.getSession();
		  
		  if(session!=null) {
			  
			  Country country = session.get(Country.class, sid);
			  
			  if(country!=null) {
				  System.out.println("######");
				  System.out.println();
				  System.out.println(country);
			  }
			  else {
				  System.out.println("######");
				  System.out.println("Sorry No country Available with given Id:"+sid);
			  }
			  
		  }
		  
		  
	}

}
