package in.bham;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvcJsonAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MvcJsonAppApplication.class, args);
	}

}
