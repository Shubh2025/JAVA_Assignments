package in.bham.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import in.bham.entity.Company;

public interface ICompanyRepo extends JpaRepository<Company, Integer> {

}
