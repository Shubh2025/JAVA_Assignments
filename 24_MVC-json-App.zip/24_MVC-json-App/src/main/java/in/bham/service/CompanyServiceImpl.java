package in.bham.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.bham.dao.ICompanyRepo;
import in.bham.entity.Company;

@Service
@Transactional
public class CompanyServiceImpl implements ICompanyServic {

	@Autowired
	private ICompanyRepo repo;
	
	@Override
	public String addComany(Company company) {
		
		Company company2 = repo.save(company);
		
		
		return "Comany with Id: "+company2.getComId()+" has been added.";
	}

}
