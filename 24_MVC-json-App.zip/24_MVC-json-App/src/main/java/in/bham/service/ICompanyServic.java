package in.bham.service;

import in.bham.entity.Company;

public interface ICompanyServic {
	
	public String addComany(Company company);

}
