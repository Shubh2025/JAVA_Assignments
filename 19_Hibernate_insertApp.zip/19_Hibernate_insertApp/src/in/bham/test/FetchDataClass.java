package in.bham.test;

import java.util.Scanner;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import in.bham.entity.Country;
import in.bham.util.HibernateUtil;

@SuppressWarnings("resource")
public class FetchDataClass {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter 1 for insertion");
		System.out.println("enter 2 for get");
		int num=sc.nextInt();
			
		switch (num) {
		case 1:
			saveTheData();
			break;
		case 2:
			getTheData();
			break;
		default:
			System.out.println("please enter appropriate number for the operations");
			break;
		}
		  
		  
	}
	
	public static void saveTheData() {
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter capital");
		String capital = sc.next();
		System.out.println("enter name");
		String name = sc.next();
		System.out.println("enter language");
		String official_language = sc.next();
		
		Session session=null;
		Transaction tnsc=null;
		boolean sts=false;
		Integer sid=0;
		
		try {
			session= HibernateUtil.getSession();
			
			if(session!=null) {
				
				tnsc=session.beginTransaction();
			}
			if(tnsc!=null) {
				Country country=new Country();
				country.setCapital(capital);
				country.setName(name);
				country.setOfficial_language(official_language);
				
				 sid = (Integer) session.save(country);
				sts=true;
				
			}
			
			
		}catch (HibernateException e) {
			e.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		if(sts==true) {
			tnsc.commit();
			System.out.println("Data Inserted Succesfully with id:"+sid);
		}
		else {
			tnsc.rollback();
			System.out.println("Insertion got failed");
		}
	}
	
	public static void getTheData() {
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter id of the country");
		int sid = sc.nextInt();
	
		
		Session session=null;
		
		try {
		   session= HibernateUtil.getSession();
		
			if(session!=null) {
				
				Country country = session.get(Country.class, sid);
				
				if(country!=null) {
					System.out.println("*******");
					System.out.println("Country is ===>"+country);
				}
				else {
					System.out.println("Sorry No Data Found");
				}
				
			}	
			
		}catch (HibernateException e) {
			e.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	
	}

}
