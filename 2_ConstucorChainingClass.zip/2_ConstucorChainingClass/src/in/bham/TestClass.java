package in.bham;

class ParentClass{
	
	public ParentClass() {
		System.out.println("Parent class Constructor is created");
	}
}

class ChildClass extends ParentClass{
	
	public ChildClass() {
		
		System.out.println();
		System.out.println("Child class Constructor is created");
	}
	
}


public class TestClass {

	public static void main(String[] args) {

		ChildClass p=new ChildClass();
		System.out.println();
		System.out.println();
		
		System.out.println("  here child class is extending parent class \n and both the classes having zero param constructors \n"
				+ "hence when child class object is created then child class constructor is called \n"
				+ "but in avery constructor first line is super method which calls the parent class constructor...    ");
	}

}
