package in.bham.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.bham.dao.IUserInfoRepo;
import in.bham.model.UserInfo;

@Service
public class UserInfroServiceImpl implements IUserInfoService {

	@Autowired
	private IUserInfoRepo repo;
	
	@Override
	public String registerUser(UserInfo userInfo) {
		
		UserInfo info = repo.save(userInfo);
				
		return "Registration Succesfull with the id: "+info.getUid();
	}


	@Override
	public UserInfo getUserBypasswordAnduserName(Integer uid, String password) {
		
		Optional<UserInfo> optional = repo.findById(uid);
		if(optional.isPresent()) {
			
			if(optional.get().getPassword().equals(password)) 
				return optional.get();
			
		}
			return null;
		  
	}

}
