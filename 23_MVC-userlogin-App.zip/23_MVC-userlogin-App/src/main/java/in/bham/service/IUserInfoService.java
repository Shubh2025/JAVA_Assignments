package in.bham.service;

import in.bham.model.UserInfo;

public interface IUserInfoService {

	public String registerUser(UserInfo userInfo);
	
	public UserInfo getUserBypasswordAnduserName(Integer uid,String password);
}
