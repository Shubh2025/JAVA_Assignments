package in.bham.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import in.bham.model.UserInfo;
import in.bham.service.IUserInfoService;

@Controller
@RequestMapping(value="/use")
public class UserController {
	
	@Autowired(required = true)
	private IUserInfoService service;
	
	@PostMapping("/add")
	public String registerUser(Map<String,Object> map,@ModelAttribute("user") UserInfo user) {
		
		String succesMsg = service.registerUser(user);
		
		map.put("msg", succesMsg);
		
		return "status";
		
	}
	
	@GetMapping("/")
	public String getPage(Map<String,Object> map,@ModelAttribute("user") UserInfo user ) {
		
		return "index";
	}
	
	@GetMapping("/login")
	public String logInpage(@ModelAttribute("usa") UserInfo user) {
		
		return "logIn";
	}
	
	@GetMapping("/chechkaro")
	public String signInpage(Map<String,Object> map,@ModelAttribute("usa") UserInfo user) {
		
		String msg="";
		UserInfo info = service.getUserBypasswordAnduserName(user.getUid(),user.getPassword() );
		if(info==null) {
		     msg="Sorry password or userId is Wrong";
		}
		else {
			 msg="Login SuccesFull";
		}
		
		map.put("msg", msg);
		return "status";
		}
	
	

}
;