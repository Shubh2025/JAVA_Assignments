package in.bham.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import in.bham.model.UserInfo;

public interface IUserInfoRepo extends JpaRepository<UserInfo, Integer> {

}
