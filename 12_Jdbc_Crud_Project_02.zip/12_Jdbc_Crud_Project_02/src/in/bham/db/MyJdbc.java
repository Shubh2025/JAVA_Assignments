package in.bham.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import in.bham.utility.JdbcUtil;

public class MyJdbc {
	
	public static void main(String[] args) { 
		
		MyJdbc db=new MyJdbc();
		 
		 Scanner sc=new Scanner(System.in);
		 
		 System.out.println("press 1 for insert Records");
		 System.out.println("press 2 for reading the Records");
		 System.out.println("press 3 for update Records");
		 System.out.println("press 4 for delete Records");
		 System.out.println("press 5 for exit the application");
		 
		 int i=sc.nextInt();
		 
		switch (i) {
		case 1:
			db.addRecords();		
			break;
		case 2:
			db.getRecords();
			break;
		case 3:
			 db.UpdateRecords();
			 break;
		case 4:
			 db.deleteRecords();
			 break;
		case 5:
			 System.exit(1);
		default:
			 System.out.println(":please enter appropriate number:");
			break;
		}
		 		 
		
	}
	
	public void addRecords() {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter capital of country");
		String capital = sc.next();
		System.out.println("enter name of the country");
		String name = sc.next();
		System.out.println("enter official language of country");
		String language = sc.next();
		
		Connection connection = JdbcUtil.getJdbcConnection();
		PreparedStatement pst=null;
		int rowUpdated=0;
		 try {
			 
				pst=connection.prepareStatement("insert into countries(capital,name,official_language) values(?,?,?)");
			
				
				if(pst!=null) {
					
					pst.setString(1, capital);
					pst.setString(2, name);
					pst.setString(3, language);
					
					rowUpdated=pst.executeUpdate();
				}
				System.out.println(rowUpdated+" row is Affected");
				
			} catch (SQLException e) {
				e.printStackTrace();
			}catch(Exception e) {
				e.printStackTrace();
			}
		
	}
	
	public void getRecords() {
	
		
		Connection connection = JdbcUtil.getJdbcConnection();
		PreparedStatement pst=null;
	    ResultSet rst=null;
		 try {
			 
				pst=connection.prepareStatement("select capital,name,official_language from countries");
			
				
				if(pst!=null) {
					
					rst=pst.executeQuery();
				}
				
				 
				  System.out.println("NAME\tCAPITAL\tLANGUAGE");
				  
				  while(rst.next()) {
					  
					  System.out.println();
					  String cap = rst.getString(1);
					  String names = rst.getString(2);
					  String Offi_language = rst.getString(3);
					  
					  System.out.println(names+"\t"+cap+"\t"+Offi_language);
					  
				  }
				
				
			} catch (SQLException e) {
				e.printStackTrace();
			}catch(Exception e) {
				e.printStackTrace();
			}
		
	}
	
	public void UpdateRecords() {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter id of the country");
		int cid = sc.nextInt();
		System.out.println("enter capital of country");
		String capital = sc.next();
		System.out.println("enter name of the country");
		String name = sc.next();
		System.out.println("enter official language of country");
		String language = sc.next();
		
		Connection connection = JdbcUtil.getJdbcConnection();
		PreparedStatement pst=null;
		int rowUpdated=0;
		try {
			
			pst=connection.prepareStatement("update countries set capital=?,name=?,official_language=? where cid=?");
			
			
			if(pst!=null) {
				
				pst.setString(1, capital);
				pst.setString(2, name);
				pst.setString(3, language);
				pst.setInt(4, cid);
				
				rowUpdated=pst.executeUpdate();
			}
			System.out.println(rowUpdated+" row is Affected");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
public void deleteRecords() {
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter id of the country");
		int cid = sc.nextInt();

		
		Connection connection = JdbcUtil.getJdbcConnection();
		PreparedStatement pst=null;
		int rowUpdated=0;
		 try {
			 
				pst=connection.prepareStatement("delete from countries where cid=?");
			
				
				if(pst!=null) {
					
			
					pst.setInt(1, cid);
					
					rowUpdated=pst.executeUpdate();
				}
				System.out.println(rowUpdated+" row is Affected");
				
			} catch (SQLException e) {
				e.printStackTrace();
			}catch(Exception e) {
				e.printStackTrace();
			}
		
	}
	
	
	

	}
