package in.bham.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class JdbcUtil {
	
	static Connection connection=null;
	
	public static Connection getJdbcConnection() {
		
		
		String url="jdbc:mysql:///assignment_spring";
		String username="root";
		String password="bhamp@143";
		
		try {
			connection = DriverManager.getConnection(url, username, password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return connection;
	}
	


}
