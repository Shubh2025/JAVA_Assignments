package in.bham.db;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import in.bham.util.JdbcUtil;

public class MyJdbcBatchUpdate {
	
	public static void main(String[] args) throws SQLException {
		
		Connection con=null;
		PreparedStatement pst=null;
		Scanner sc=null;
		
		 try {
			con = JdbcUtil.getJdbcConnection();
			
		    if(con!=null) {
		    	 pst = con.prepareStatement("insert into countries(capital,name,official_language)values(?,?,?)");	
		    }
		    if(pst!=null) {
		    	
		    	while(true) {
		    		
		    		sc=new Scanner(System.in);
		    		
		    		System.out.println("enter capital");
		    		String capi = sc.next();
		    		System.out.println("enter Name");
		    		String name = sc.next();
		    		System.out.println("enter language");
		    		String lan = sc.next();
		    		
		    		pst.setString(1, capi);
		    		pst.setString(2, name);
		    		pst.setString(3, lan);
		    		
		    		pst.addBatch();
		    		
		    		System.out.println("Do you want to add more data into database(Y/N)");
		    		String ans = sc.next();
		    		
		    		if(ans.equalsIgnoreCase("N")) {
		    			break;
		    		}
		    		
		    	}
		    	
		    	pst.executeBatch();
		    	
		    	System.out.println("update succesfull...");
		    	
		    	
		    }
			
		} catch (IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			
			JdbcUtil.closeAllresources(con, pst, null);
		}
		
		
	}

}
