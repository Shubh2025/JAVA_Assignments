package in.bham.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

public class JdbcUtil {
	
	private JdbcUtil() {};
	
	static {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public static Connection getJdbcConnection() throws IOException, SQLException {
		
	
			FileInputStream fis=new FileInputStream("D:\\JDBC(Assignment)\\13_JdbcBatch_ProjApp\\src\\in\\bham\\properties\\application.properties");
			
			Properties prp=new Properties();
			prp.load(fis);
			
			Connection connection=DriverManager.getConnection(prp.getProperty("jdbcUrl"), prp.getProperty("user"), prp.getProperty("password"));
			
			return connection;
		
	}
	public static void closeAllresources(Connection connection,PreparedStatement pst,ResultSet rst) throws SQLException {
		
		if(connection!=null) {
			connection.close();
		}
		if(pst!=null) {
			pst.close();
		}
		if(rst!=null) {
			rst.close();
		}
		
	}

}
