package in.bham.test;

import java.util.Scanner;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import in.bham.entity.Country;
import in.bham.util.HibernateUtil;

@SuppressWarnings("resource")
public class FetchDataClass {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter 1 for update the data");
		System.out.println("enter 2 for getting tha data");
		int num=sc.nextInt();
			
		switch (num) {
		case 1:
			updateTheData();
			break;
		case 2:
			getTheData();
			break;
		default:
			System.out.println("please enter appropriate number for the operations");
			break;
		}
		  
		  
	}
	
	public static void updateTheData() {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the id of country");
		int id = sc.nextInt();
		System.out.println("enter new capital");
		String capital = sc.next();
		System.out.println("enter new language if exist");
		String language = sc.next();
	
		
		Session session=null;
		Transaction tnsc=null;
		boolean sts=false;
		
		
		try {
			session= HibernateUtil.getSession();
			 Country country2 = session.get(Country.class, id);
			 
			
			if(session!=null) {
				
				tnsc=session.beginTransaction();
			}
			if(tnsc!=null) {
				
				if(country2!=null) {
					
					country2.setCapital(capital);
					
				
				
						country2.setOfficial_language(language);
						session.update(country2);
						sts=true;
					
				}
			
				
			}
			
			
		}catch (HibernateException e) {
			e.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		if(sts==true) {
			tnsc.commit();
			System.out.println("Data Updated Succesfully with id:"+id);
		}
		else {
			tnsc.rollback();
			System.out.println("for given id data is not available");
		}
	}
	
	public static void getTheData() {
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter id of the country");
		int sid = sc.nextInt();
	
		
		Session session=null;
		
		try {
		   session= HibernateUtil.getSession();
		
			if(session!=null) {
				
				Country country = session.get(Country.class, sid);
				
				if(country!=null) {
					System.out.println("*******");
					System.out.println("Country is ===>"+country);
				}
				else {
					System.out.println("Sorry No Data Found");
				}
				
			}	
			
		}catch (HibernateException e) {
			e.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	
	}

}
