package in.bham;

import java.util.Scanner;

public class TestClass {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("for Deposit ====> 1");
		System.out.println("for Withdraw rupees ===> 2");
		System.out.println("for checking the balance ===> 3");
		
		Bank bank = new Bank();
		
		
		int i = sc.nextInt();
		if(i==1) {
			System.out.println("enter the amount");
			double amount = sc.nextDouble();
			bank.setBalance(bank.getBalance()+amount);
			System.out.println("Amount succesfully credited to your account");
			System.out.println("Total balance:"+(bank.getBalance()+amount));
		}
		if(i==2) {
			System.out.println("enter the amount which you want to withdraw");
			double amount = sc.nextDouble();
			if(bank.getBalance()>amount) {
				
				bank.setBalance(bank.getBalance()-amount);
				System.out.println("Total balance:"+(bank.getBalance()-amount));
				
			}else {
				System.out.println("insufficient balance");
			}
		}
		if(i==3) {
			System.out.println("BALANCE:: "+bank.getBalance());
		}
	}

}
