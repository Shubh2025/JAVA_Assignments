package in.bham;

public class Bank {
	
	private double balance;
		

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	

}
