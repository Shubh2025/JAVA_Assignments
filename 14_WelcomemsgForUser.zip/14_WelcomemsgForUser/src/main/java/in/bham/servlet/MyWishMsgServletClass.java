package in.bham.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MyWishMsgServletClass
 */
@WebServlet("/wish")
public class MyWishMsgServletClass extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public MyWishMsgServletClass() {
        // TODO Auto-generated constructor stub
    	System.out.println("servlet class constructor has been created");
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    
		String name = request.getParameter("name");
		
		LocalDateTime date=LocalDateTime.now();
		
		int hour = date.getHour();
		System.out.println(hour);
		String msg="";
		
		if(hour<=12) {
			msg="good Morning "+name;
		}
		if(hour>12 && hour<16) {
			msg="good Afternoon "+name;
		}
		if(hour>16 && hour<18) {
			msg="good Evening "+name;
		}
		if(hour>18 && hour<24) {
			msg="good Night "+name;
		}
		
		PrintWriter out = response.getWriter();
		
		out.println("<h1 style='color: green; text-align: center;'>WELCOME PAGE</h1>");
		
		out.println("<h1 style='color: green; text-align: center;'>"+msg+" </h1>");
		
	      
	}
	

}
