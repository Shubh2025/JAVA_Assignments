
class UserThread1 implements  Runnable{
	
	public void run() {
	
		
		
		for(int i=2;i<=10;i=i+2) {
			
			System.out.println(i);
		}
	}
}

class UserThread2 implements  Runnable{
	
	public void run() {
		
		for(int i=1;i<=10;i=i+2) {
		    
			System.out.println(i);
		}
	}
}


public class TestThread {

	public static void main(String[] args) {
		
		UserThread1 r1=new UserThread1();
		Thread th1=new Thread(r1);
		
		UserThread2 r2=new UserThread2();
		Thread th2=new Thread(r2);
		
		th1.setPriority(5);
		th2.setPriority(8);
		
		th1.start();
		th2.start();
		
	}

}
